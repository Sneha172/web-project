const popover = new bootstrap.Popover('.popover-dismiss', {
    trigger: 'focus'
  })